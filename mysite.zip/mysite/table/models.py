from django.db import models


class Company(models.Model):
    name = models.CharField(max_length=100)
    contact_name = models.CharField(max_length=100)
    address = models.TextField(max_length=255)
    ph_no = models.CharField(max_length=17)
    tele = models.CharField(max_length=17)
    mail = models.EmailField(max_length=150)
    is_delete = models.BinaryField(default=0)
    is_active = models.BinaryField(default=0)


class Client(models.Model):
    company_id = models.IntegerField()
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    address = models.TextField(max_length=255)
    ph_no = models.CharField(max_length=17)
    tele = models.CharField(max_length=17)
    mail = models.CharField(max_length=100)
    is_delete = models.BinaryField(default=0)
    is_active = models.BinaryField(default=1)


class Product(models.Model):
    company_id = models.IntegerField()
    product_type_id = models.IntegerField()
    scale_id = models.IntegerField()
    name = models.CharField(max_length=100)
    cost = models.IntegerField()
    min_threshold = models.IntegerField()
    is_delete = models.BinaryField(default=0)
    is_active = models.IntegerField(default=1)


class Vendor(models.Model):
    company_id = models.IntegerField()
    name = models.CharField(max_length=100)
    contact_name = models.CharField(max_length=100)
    address = models.TextField(max_length=255)
    ph_no = models.CharField(max_length=17)
    tele = models.CharField(max_length=17)
    mail = models.EmailField(max_length=255)
    is_delete = models.BinaryField(default=0)
    is_active = models.BinaryField(default=1)


class UserLogin(models.Model):
    company_id = models.IntegerField()
    role_id = models.IntegerField()
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    address = models.TextField(max_length=255)
    ph_no = models.CharField(max_length=100)
    tele = models.CharField(max_length=100)
    mail = models.EmailField(max_length=100)
    user_name = models.CharField(max_length=175)
    login_pass = models.CharField(max_length=100)
    is_active = models.BinaryField(default=1)
    is_delete = models.BinaryField(default=0)


class PurchaseMaster(models.Model):
    type_of_purchase = models.BinaryField()
    party_id = models.IntegerField()
    date = models.DateTimeField()
    cost = models.IntegerField()
    discount = models.IntegerField()
    aftercharges = models.IntegerField()
    payable_amount = models.IntegerField()
    is_paid = models.BinaryField()
    is_approved = models.BinaryField()
    is_delete = models.BinaryField()
    insert_date = models.DateTimeField()
    approved_date = models.DateTimeField()
    insert_by = models.IntegerField()
    approved_by = models.IntegerField()


class PurchaseDetails(models.Model):
    master_id = models.IntegerField()
    product_id = models.IntegerField()
    total_count = models.IntegerField()
    cost_per_unit = models.IntegerField()
    total_cost = models.IntegerField()
    last_update = models.DateTimeField()
    is_deleted = models.BinaryField()


class Invoice(models.Model):
    client_id = models.IntegerField()
    vendor_id = models.IntegerField()
    product_id = models.IntegerField()
    vessel_name = models.CharField(max_length=150)
    po = models.CharField(max_length=100)
    invoice_no = models.CharField(max_length=100)
    date = models.DateTimeField()
    amount = models.FloatField()
    cgst = models.FloatField()
    sgst = models.FloatField()
    total_amount = models.FloatField()
    item1 = models.CharField(max_length=100)
    item2 = models.CharField(max_length=100)
    item3 = models.CharField(max_length=100)
    cost1 = models.FloatField()
    cost2 = models.FloatField()
    cost3 = models.FloatField()


class Data(models.Model):
    name_client = models.CharField(max_length=100)
    address_client = models.CharField(max_length=255)
    name_company = models.CharField(max_length=100)
    address_company = models.CharField(max_length=255)
    vessel_name = models.CharField(max_length=100)
    po = models.CharField(max_length=100)
    invoice_number = models.CharField(max_length=100)
    date = models.DateField()
    item1 = models.CharField(max_length=100)
    gst1 = models.IntegerField()
    cost1 = models.IntegerField()
    item2 = models.CharField(max_length=100)
    gst2 = models.IntegerField()
    cost2 = models.IntegerField()
    item3 = models.CharField(max_length=100)
    gst3 = models.IntegerField()
    cost3 = models.IntegerField()
    total = models.IntegerField()
    is_paid = models.BinaryField(default=0)
    is_delete = models.BinaryField(default=0)
    is_approved = models.BinaryField(default=0)
    remarks = models.TextField(max_length=355)
