from django.apps import AppConfig


class TableConfig(AppConfig):
    name = 'table'
